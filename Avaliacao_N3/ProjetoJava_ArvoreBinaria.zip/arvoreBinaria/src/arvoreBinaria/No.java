package arvoreBinaria;


class No {
	int numero;
	No esquerda;
	No direita;

	public No(Integer numero) {
		this.numero = numero;
		this.esquerda = null;
		this.direita = null;
	}

}
